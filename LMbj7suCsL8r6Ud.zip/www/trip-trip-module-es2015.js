(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["trip-trip-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/trip/trip.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/trip/trip.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n    <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n            <ion-back-button defaultHref=\"trips\"></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-title>Putovanje</ion-title>\r\n        <ion-icon name=\"create-outline\" slot=\"end\" style=\"font-size: 4vh;\" class=\"ion-padding\" *ngIf=\"isAdmin\"\r\n            (click)=\"editTrip()\">\r\n        </ion-icon>\r\n        <ion-icon name=\"bookmark-outline\" slot=\"end\" style=\"font-size: 4vh;\" class=\"ion-padding\"\r\n            *ngIf=\"isLogged && !favorite\" (click)=\"addToFavorites()\"></ion-icon>\r\n        <ion-icon name=\"bookmark\" slot=\"end\" style=\"font-size: 4vh;\" class=\"ion-padding\" *ngIf=\"isLogged && favorite\"\r\n            (click)=\"removeFromFavorites()\"></ion-icon>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <div class=\"ion-margin\" *ngIf=\"!trip\">\r\n        <ion-spinner color=\"primary\" class=\"spinner-position\"></ion-spinner>\r\n    </div>\r\n    <div *ngIf=\"trip\">\r\n        <ion-img [src]='trip.imageSrc ? trip.imageSrc : defaultImgSrc' alt=\"grad\"></ion-img>\r\n        <ion-grid>\r\n            <ion-row>\r\n                <ion-col size=\"8\">\r\n                    <ion-title class=\"ion-padding headline-text\"><strong>{{ trip.city ? trip.city : trip.country.name }}</strong></ion-title>\r\n                </ion-col>\r\n                <ion-col size=\"4\">\r\n                    <ion-title class=\"ion-padding text-price headline-text\"><strong>{{ trip.price }} &euro;</strong>\r\n                    </ion-title>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <ion-item>\r\n                        <ion-icon name=\"calendar-outline\" class=\"ion-padding-end\"></ion-icon>\r\n                        <ion-label class=\"ion-no-margin\">{{ dateFormat(trip.travelDate, trip.returnDate) }}</ion-label>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <ion-item>\r\n                        <ion-icon name=\"airplane-outline\" class=\"ion-padding-end\"></ion-icon>\r\n                        <ion-label class=\"ion-no-margin\">Aerodrom {{ trip.airport.airportName }}</ion-label>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <ion-item>\r\n                        <ion-icon name=\"briefcase-outline\" class=\"ion-padding-end\"></ion-icon>\r\n                        <ion-label class=\"ion-no-margin\">{{ trip.baggage }}</ion-label>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <ion-item>\r\n                        <ion-icon name=\"bed-outline\" class=\"ion-padding-end\"></ion-icon>\r\n                        <ion-label class=\"ion-no-margin\">Hotel {{ trip.hotel }}</ion-label>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <ion-item>\r\n                        <ion-icon name=\"fast-food-outline\" class=\"ion-padding-end\"></ion-icon>\r\n                        <ion-label class=\"ion-no-margin\">{{ trip.meal ? trip.meal : 'Bez obroka na putovanju'}}\r\n                        </ion-label>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <ion-item>\r\n                        <ion-text class=\"ion-padding-vertical\"><i>\"{{ trip.quote }}\"</i> - {{ trip.author }}</ion-text>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\">\r\n                    <ion-item>\r\n                        <ion-img [src]=\"weatherIcon\" style=\"height: 8vh;\" class=\"ion-no-padding\"></ion-img>\r\n                        <ion-text>Trenutna temperatura: {{ temperature }}&deg; C</ion-text>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" class=\"ion-padding\">\r\n                    <ion-text style=\"white-space: pre-line\">\r\n                        {{ trip.description ? trip.description : desc }}\r\n                    </ion-text>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"6\">\r\n                    <ion-button shape=\"round\" color=\"primary\" style=\"width: 100%;\">\r\n                        Rezerviši\r\n                    </ion-button>\r\n                </ion-col>\r\n                <ion-col size=\"6\">\r\n                    <ion-button shape=\"round\" color=\"primary\" style=\"width: 100%;\">\r\n                        Drugi datum?\r\n                    </ion-button>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n    </div>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/trip/trip-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/trip/trip-routing.module.ts ***!
  \*********************************************/
/*! exports provided: TripPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripPageRoutingModule", function() { return TripPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _trip_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./trip.page */ "./src/app/trip/trip.page.ts");




const routes = [
    {
        path: 'new-trip/:tripID',
        loadChildren: () => Promise.all(/*! import() | trip-new-trip-new-trip-module */[__webpack_require__.e("common"), __webpack_require__.e("trip-new-trip-new-trip-module")]).then(__webpack_require__.bind(null, /*! ../trip/new-trip/new-trip.module */ "./src/app/trip/new-trip/new-trip.module.ts")).then(m => m.NewTripPageModule)
    },
    {
        path: 'new-trip',
        loadChildren: () => Promise.all(/*! import() | trip-new-trip-new-trip-module */[__webpack_require__.e("common"), __webpack_require__.e("trip-new-trip-new-trip-module")]).then(__webpack_require__.bind(null, /*! ../trip/new-trip/new-trip.module */ "./src/app/trip/new-trip/new-trip.module.ts")).then(m => m.NewTripPageModule)
    },
    {
        path: 'edit-trip',
        loadChildren: () => __webpack_require__.e(/*! import() | trip-edit-trip-edit-trip-module */ "trip-edit-trip-edit-trip-module").then(__webpack_require__.bind(null, /*! ../trip/edit-trip/edit-trip.module */ "./src/app/trip/edit-trip/edit-trip.module.ts")).then(m => m.EditTripPageModule)
    },
    {
        path: ':tripID',
        component: _trip_page__WEBPACK_IMPORTED_MODULE_3__["TripPage"]
    },
];
let TripPageRoutingModule = class TripPageRoutingModule {
};
TripPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TripPageRoutingModule);



/***/ }),

/***/ "./src/app/trip/trip.module.ts":
/*!*************************************!*\
  !*** ./src/app/trip/trip.module.ts ***!
  \*************************************/
/*! exports provided: TripPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripPageModule", function() { return TripPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _trip_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./trip-routing.module */ "./src/app/trip/trip-routing.module.ts");
/* harmony import */ var _trip_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./trip.page */ "./src/app/trip/trip.page.ts");







let TripPageModule = class TripPageModule {
};
TripPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _trip_routing_module__WEBPACK_IMPORTED_MODULE_5__["TripPageRoutingModule"]
        ],
        declarations: [_trip_page__WEBPACK_IMPORTED_MODULE_6__["TripPage"]]
    })
], TripPageModule);



/***/ }),

/***/ "./src/app/trip/trip.page.scss":
/*!*************************************!*\
  !*** ./src/app/trip/trip.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-price {\n  text-align: right;\n}\n\n.headline-text {\n  font-size: 3vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdHJpcC9DOlxcVXNlcnNcXE9va2VlXFxEZXNrdG9wXFxaYXZydGkgZ2xvYnVzXFx6YXZydGlnbG9idXMtaW9uaWMvc3JjXFxhcHBcXHRyaXBcXHRyaXAucGFnZS5zY3NzIiwic3JjL2FwcC90cmlwL3RyaXAucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3RyaXAvdHJpcC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dC1wcmljZXtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcblxyXG4uaGVhZGxpbmUtdGV4dHtcclxuICAgIGZvbnQtc2l6ZTogM3ZoO1xyXG59XHJcblxyXG4uc3Bpbm5lci1wb3NpdGlvbntcclxuICAgIC8vcG9zaXRpb246IGZpeGVkO1xyXG4gICAgLy90b3A6IDUwJTtcclxuICAgIC8vbWFyZ2luOiBhdXRvIDA7XHJcbiAgICAvL3RyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG59IiwiLnRleHQtcHJpY2Uge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLmhlYWRsaW5lLXRleHQge1xuICBmb250LXNpemU6IDN2aDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/trip/trip.page.ts":
/*!***********************************!*\
  !*** ./src/app/trip/trip.page.ts ***!
  \***********************************/
/*! exports provided: TripPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripPage", function() { return TripPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _trip_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./trip.service */ "./src/app/trip/trip.service.ts");
/* harmony import */ var _favorite_trips_favorite_trips_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../favorite-trips/favorite-trips.service */ "./src/app/favorite-trips/favorite-trips.service.ts");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");







let TripPage = class TripPage {
    constructor(route, navCtrl, tripService, favoriteTripsService, authService) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.tripService = tripService;
        this.favoriteTripsService = favoriteTripsService;
        this.authService = authService;
        this.isLogged = false;
        this.isAdmin = false;
        this.favorite = false;
        this.desc = "Aranžman ne uključuje:\n•Transfer aerodrom-hotel-aerodrom.\n---------------------------------------------\nCena aranžmana formirana je na dan objavljivanja ponude.\n\nZa sve nedoumice, pitanja i prijave javite nam se privatnom porukom ili na mail zavrtiglobus@gmail.com";
        this.defaultImgSrc = "../../assets/img/trips/1.jpg";
    }
    ngOnInit() {
        this.route.paramMap.subscribe((paramMap) => {
            if (!paramMap.has("tripID")) {
                this.navCtrl.navigateBack("/trips");
                return;
            }
            this.tripID = +paramMap.get("tripID");
            this.tripSub = this.tripService
                .fetchTripByID(this.tripID)
                .subscribe((trip) => {
                this.trip = trip;
                console.log(trip);
                this.tripService.getWeather(this.trip.city).subscribe((weather) => {
                    console.log(weather);
                    this.temperature = Math.round(weather.main.temp);
                    this.weatherIcon = `https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`;
                });
            });
            this.authService.userIsAuthenticated.subscribe((isLogged) => {
                this.isLogged = isLogged;
            });
            this.authService.userID.subscribe(userID => {
                this.favSub = this.tripService
                    .chechFavorite(userID, this.tripID)
                    .subscribe((data) => {
                    if (data != null)
                        this.favorite = true;
                    else
                        this.favorite = false;
                });
                this.authService.userIsAdmin.subscribe(isAdmin => {
                    this.isAdmin = isAdmin;
                });
            });
        });
    }
    ngOnDestroy() {
        this.tripSub.unsubscribe();
    }
    toggleFavorite() {
        this.favorite = !this.favorite;
    }
    dateFormat(dateFrom, dateTo) {
        var dayFrom = dateFrom.getUTCDate();
        var monthFrom = dateFrom.getUTCMonth() + 1;
        var yearFrom = dateFrom.getUTCFullYear();
        var dayTo = dateTo.getUTCDate();
        var monthTo = dateTo.getUTCMonth() + 1;
        var yearTo = dateTo.getUTCFullYear();
        if (yearFrom === yearTo) {
            if (monthFrom === monthTo) {
                if (dayFrom === dayTo) {
                    return `${dayFrom}. ${this.monthFormat(monthFrom)} ${yearFrom}.`;
                }
                else {
                    return `${dayFrom}-${dayTo}. ${this.monthFormat(monthFrom)} ${yearFrom}.`;
                }
            }
            else {
                return `${dayFrom}. ${this.monthFormat(monthFrom)} - ${dayTo}. ${this.monthFormat(monthTo)} ${yearFrom}.`;
            }
        }
        else {
            return `${dayFrom}. ${this.monthFormat(monthFrom)} ${yearFrom} - ${dayTo}. ${this.monthFormat(monthTo)} ${yearTo}.`;
        }
    }
    monthFormat(month) {
        switch (month) {
            case 1:
                return "jan";
            case 2:
                return "feb";
            case 3:
                return "mar";
            case 4:
                return "apr";
            case 5:
                return "maj";
            case 6:
                return "jun";
            case 7:
                return "jul";
            case 8:
                return "avg";
            case 9:
                return "sep";
            case 10:
                return "okt";
            case 11:
                return "nov";
            case 12:
                return "dec";
            default:
                return "null";
        }
    }
    addToFavorites() {
        this.authService.userID.subscribe((userID) => {
            this.tripService.addToFavorites(userID, this.tripID).subscribe(() => {
                this.favorite = true;
                this.favoriteTripsService.getFavorites(userID).subscribe();
            });
        });
    }
    removeFromFavorites() {
        this.authService.userID.subscribe(userID => {
            this.tripService
                .removeFromFavorites(userID, this.tripID)
                .subscribe(() => {
                this.favorite = false;
                this.favoriteTripsService.getFavorites(userID).subscribe();
            });
        });
    }
    editTrip() {
        this.navCtrl.navigateForward(`/trips/trip/new-trip/${this.tripID}`);
    }
};
TripPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _trip_service__WEBPACK_IMPORTED_MODULE_4__["TripService"] },
    { type: _favorite_trips_favorite_trips_service__WEBPACK_IMPORTED_MODULE_5__["FavoriteTripsService"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] }
];
TripPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-trip",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./trip.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/trip/trip.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./trip.page.scss */ "./src/app/trip/trip.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
        _trip_service__WEBPACK_IMPORTED_MODULE_4__["TripService"],
        _favorite_trips_favorite_trips_service__WEBPACK_IMPORTED_MODULE_5__["FavoriteTripsService"],
        _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"]])
], TripPage);



/***/ })

}]);
//# sourceMappingURL=trip-trip-module-es2015.js.map