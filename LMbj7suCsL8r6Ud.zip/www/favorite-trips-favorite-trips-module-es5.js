(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["favorite-trips-favorite-trips-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/favorite-trips/favorite-trips.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/favorite-trips/favorite-trips.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n    <ion-title>Omiljena putovanja</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"ion-padding ion-text-center\" *ngIf=\"!showList\">\r\n    <ion-title>Nemate omiljenih putovanja</ion-title>\r\n  </div>\r\n\r\n  <div *ngIf=\"showList\">\r\n    <ion-card *ngFor=\"let favorite of favorites\">\r\n      <ion-item-sliding>\r\n        <ion-item [routerLink]=\"['/', 'trips', 'trip', favorite.tripID]\">\r\n          <ion-thumbnail>\r\n            <img [src]='favorite.imageSrc ? favorite.imageSrc : defaultImg' />\r\n          </ion-thumbnail>\r\n          <ion-grid>\r\n            <ion-row>\r\n              <ion-col size=\"8\">\r\n                <ion-row>\r\n                  <ion-col>\r\n                    <ion-title class=\"ion-no-padding\"><strong>{{ favorite.city? favorite.city : favorite.country }}</strong>\r\n                    </ion-title>\r\n                  </ion-col>\r\n                </ion-row>\r\n                <ion-row>\r\n                  <ion-col>\r\n                    <ion-text class=\"ion-no-padding\">{{ dateFormat(favorite.travelDate, favorite.returnDate) }}</ion-text>\r\n                  </ion-col>\r\n                </ion-row>\r\n              </ion-col>\r\n              <ion-col size=\"4\" class=\"col-price\">\r\n                <ion-title class=\"ion-no-padding text-price\"><strong>{{ favorite.price }} &euro;</strong></ion-title>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n          <ion-icon name=\"chevron-forward-outline\" slot=\"end\" class=\"ion-no-margin\"></ion-icon>\r\n        </ion-item>\r\n        <ion-item-options side=\"end\">\r\n          <ion-item-option color=\"danger\" (click)=\"removeFavorite(favorite.tripID)\">\r\n            <ion-icon name=\"trash-outline\" style=\"font-size: 4vh;\" slot=\"icon-only\"></ion-icon>\r\n          </ion-item-option>\r\n        </ion-item-options>\r\n      </ion-item-sliding>\r\n    </ion-card>\r\n  </div>\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/favorite-trips/favorite-trips-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/favorite-trips/favorite-trips-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: FavoriteTripsPageRoutingModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FavoriteTripsPageRoutingModule", function () {
      return FavoriteTripsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _favorite_trips_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./favorite-trips.page */
    "./src/app/favorite-trips/favorite-trips.page.ts");

    const routes = [{
      path: '',
      component: _favorite_trips_page__WEBPACK_IMPORTED_MODULE_3__["FavoriteTripsPage"]
    }];
    let FavoriteTripsPageRoutingModule = class FavoriteTripsPageRoutingModule {};
    FavoriteTripsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], FavoriteTripsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/favorite-trips/favorite-trips.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/favorite-trips/favorite-trips.module.ts ***!
    \*********************************************************/

  /*! exports provided: FavoriteTripsPageModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FavoriteTripsPageModule", function () {
      return FavoriteTripsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _favorite_trips_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./favorite-trips-routing.module */
    "./src/app/favorite-trips/favorite-trips-routing.module.ts");
    /* harmony import */


    var _favorite_trips_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./favorite-trips.page */
    "./src/app/favorite-trips/favorite-trips.page.ts");

    let FavoriteTripsPageModule = class FavoriteTripsPageModule {};
    FavoriteTripsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _favorite_trips_routing_module__WEBPACK_IMPORTED_MODULE_5__["FavoriteTripsPageRoutingModule"]],
      declarations: [_favorite_trips_page__WEBPACK_IMPORTED_MODULE_6__["FavoriteTripsPage"]]
    })], FavoriteTripsPageModule);
    /***/
  },

  /***/
  "./src/app/favorite-trips/favorite-trips.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/favorite-trips/favorite-trips.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".text-price {\n  text-align: right;\n}\n\n.col-price {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmF2b3JpdGUtdHJpcHMvQzpcXFVzZXJzXFxPb2tlZVxcRGVza3RvcFxcWmF2cnRpIGdsb2J1c1xcemF2cnRpZ2xvYnVzLWlvbmljL3NyY1xcYXBwXFxmYXZvcml0ZS10cmlwc1xcZmF2b3JpdGUtdHJpcHMucGFnZS5zY3NzIiwic3JjL2FwcC9mYXZvcml0ZS10cmlwcy9mYXZvcml0ZS10cmlwcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQ0NKOztBREVBO0VBQ0ksb0JBQUE7RUFBQSxhQUFBO0VBQ0Esd0JBQUE7VUFBQSx1QkFBQTtFQUNBLHlCQUFBO1VBQUEsbUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2Zhdm9yaXRlLXRyaXBzL2Zhdm9yaXRlLXRyaXBzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50ZXh0LXByaWNlIHtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcblxyXG4uY29sLXByaWNlIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn0iLCIudGV4dC1wcmljZSB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4uY29sLXByaWNlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/favorite-trips/favorite-trips.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/favorite-trips/favorite-trips.page.ts ***!
    \*******************************************************/

  /*! exports provided: FavoriteTripsPage */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FavoriteTripsPage", function () {
      return FavoriteTripsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _favorite_trips_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./favorite-trips.service */
    "./src/app/favorite-trips/favorite-trips.service.ts");
    /* harmony import */


    var _trip_trip_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../trip/trip.service */
    "./src/app/trip/trip.service.ts");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../auth/auth.service */
    "./src/app/auth/auth.service.ts");

    let FavoriteTripsPage = class FavoriteTripsPage {
      constructor(favoriteTripsService, tripServce, authService) {
        this.favoriteTripsService = favoriteTripsService;
        this.tripServce = tripServce;
        this.authService = authService;
        this.favorites = [];
        this.showList = false; //userID = 1;

        this.defaultImg = "../../assets/img/trips/1.jpg";
      }

      ngOnInit() {
        /*this.favSub =*/
        this.favoriteTripsService.favorites.subscribe(favs => {
          console.log("sub");
          this.favorites = favs;
          console.log(this.favorites);
          if (this.favorites.length > 0) this.showList = true;else this.showList = false;
        });
      }

      ionViewWillEnter() {
        console.log("enter");
        this.authService.userID.subscribe(userID => {
          this.favoriteTripsService.getFavorites(userID).subscribe();
        });
      }

      ngOnDestroy() {
        if (this.favSub) this.favSub.unsubscribe();
      }

      removeFavorite(tripID) {
        this.authService.userID.subscribe(userID => {
          this.tripServce.removeFromFavorites(userID, tripID).subscribe(() => {
            console.log("Trip id je ".concat(tripID));
            this.favoriteTripsService.getFavorites(userID).subscribe();
            console.log("uklonio ".concat(tripID));
          });
        });
      }

      dateFormat(dateFrom, dateTo) {
        var dayFrom = dateFrom.getUTCDate();
        var monthFrom = dateFrom.getUTCMonth() + 1;
        var yearFrom = dateFrom.getUTCFullYear();
        var dayTo = dateTo.getUTCDate();
        var monthTo = dateTo.getUTCMonth() + 1;
        var yearTo = dateTo.getUTCFullYear();

        if (yearFrom === yearTo) {
          if (monthFrom === monthTo) {
            if (dayFrom === dayTo) {
              return "".concat(dayFrom, ". ").concat(this.monthFormat(monthFrom), " ").concat(yearFrom, ".");
            } else {
              return "".concat(dayFrom, "-").concat(dayTo, ". ").concat(this.monthFormat(monthFrom), " ").concat(yearFrom, ".");
            }
          } else {
            return "".concat(dayFrom, ". ").concat(this.monthFormat(monthFrom), " - ").concat(dayTo, ". ").concat(this.monthFormat(monthTo), " ").concat(yearFrom, ".");
          }
        } else {
          return "".concat(dayFrom, ". ").concat(this.monthFormat(monthFrom), " ").concat(yearFrom, " - ").concat(dayTo, ". ").concat(this.monthFormat(monthTo), " ").concat(yearTo, ".");
        }
      }

      monthFormat(month) {
        switch (month) {
          case 1:
            return "jan";

          case 2:
            return "feb";

          case 3:
            return "mar";

          case 4:
            return "apr";

          case 5:
            return "maj";

          case 6:
            return "jun";

          case 7:
            return "jul";

          case 8:
            return "avg";

          case 9:
            return "sep";

          case 10:
            return "okt";

          case 11:
            return "nov";

          case 12:
            return "dec";

          default:
            return "null";
        }
      }

    };

    FavoriteTripsPage.ctorParameters = () => [{
      type: _favorite_trips_service__WEBPACK_IMPORTED_MODULE_2__["FavoriteTripsService"]
    }, {
      type: _trip_trip_service__WEBPACK_IMPORTED_MODULE_3__["TripService"]
    }, {
      type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
    }];

    FavoriteTripsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: "app-favorite-trips",
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./favorite-trips.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/favorite-trips/favorite-trips.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./favorite-trips.page.scss */
      "./src/app/favorite-trips/favorite-trips.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_favorite_trips_service__WEBPACK_IMPORTED_MODULE_2__["FavoriteTripsService"], _trip_trip_service__WEBPACK_IMPORTED_MODULE_3__["TripService"], _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])], FavoriteTripsPage);
    /***/
  }
}]);
//# sourceMappingURL=favorite-trips-favorite-trips-module-es5.js.map