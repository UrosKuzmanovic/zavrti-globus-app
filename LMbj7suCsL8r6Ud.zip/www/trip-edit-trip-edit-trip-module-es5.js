(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["trip-edit-trip-edit-trip-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/trip/edit-trip/edit-trip.page.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/trip/edit-trip/edit-trip.page.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n    <ion-title>Izmeni putovanje</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/trip/edit-trip/edit-trip-routing.module.ts":
  /*!************************************************************!*\
    !*** ./src/app/trip/edit-trip/edit-trip-routing.module.ts ***!
    \************************************************************/

  /*! exports provided: EditTripPageRoutingModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditTripPageRoutingModule", function () {
      return EditTripPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _edit_trip_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./edit-trip.page */
    "./src/app/trip/edit-trip/edit-trip.page.ts");

    const routes = [{
      path: '',
      component: _edit_trip_page__WEBPACK_IMPORTED_MODULE_3__["EditTripPage"]
    }];
    let EditTripPageRoutingModule = class EditTripPageRoutingModule {};
    EditTripPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], EditTripPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/trip/edit-trip/edit-trip.module.ts":
  /*!****************************************************!*\
    !*** ./src/app/trip/edit-trip/edit-trip.module.ts ***!
    \****************************************************/

  /*! exports provided: EditTripPageModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditTripPageModule", function () {
      return EditTripPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _edit_trip_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./edit-trip-routing.module */
    "./src/app/trip/edit-trip/edit-trip-routing.module.ts");
    /* harmony import */


    var _edit_trip_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./edit-trip.page */
    "./src/app/trip/edit-trip/edit-trip.page.ts");

    let EditTripPageModule = class EditTripPageModule {};
    EditTripPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _edit_trip_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditTripPageRoutingModule"]],
      declarations: [_edit_trip_page__WEBPACK_IMPORTED_MODULE_6__["EditTripPage"]]
    })], EditTripPageModule);
    /***/
  },

  /***/
  "./src/app/trip/edit-trip/edit-trip.page.scss":
  /*!****************************************************!*\
    !*** ./src/app/trip/edit-trip/edit-trip.page.scss ***!
    \****************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RyaXAvZWRpdC10cmlwL2VkaXQtdHJpcC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/trip/edit-trip/edit-trip.page.ts":
  /*!**************************************************!*\
    !*** ./src/app/trip/edit-trip/edit-trip.page.ts ***!
    \**************************************************/

  /*! exports provided: EditTripPage */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditTripPage", function () {
      return EditTripPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    let EditTripPage = class EditTripPage {
      constructor() {}

      ngOnInit() {}

    };
    EditTripPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: "app-edit-trip",
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./edit-trip.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/trip/edit-trip/edit-trip.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./edit-trip.page.scss */
      "./src/app/trip/edit-trip/edit-trip.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], EditTripPage);
    /***/
  }
}]);
//# sourceMappingURL=trip-edit-trip-edit-trip-module-es5.js.map