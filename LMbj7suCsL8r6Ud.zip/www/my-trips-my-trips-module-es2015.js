(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["my-trips-my-trips-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/my-trips/my-trips.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/my-trips/my-trips.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n  <ion-tabs>\r\n    <ion-tab-bar slot=\"bottom\">\r\n      <ion-tab-button tab=\"favorite-trips\">\r\n        <ion-icon name=\"bookmark-outline\"></ion-icon>\r\n        <ion-label>Omiljena</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"booked-trips\">\r\n        <ion-icon name=\"book-outline\"></ion-icon>\r\n        <ion-label>Rezervisana</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"inquiry-trips\">\r\n        <ion-icon name=\"mail-outline\"></ion-icon>\r\n        <ion-label>Poslati upiti</ion-label>\r\n      </ion-tab-button>\r\n    </ion-tab-bar>\r\n  </ion-tabs>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/my-trips/my-trips-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/my-trips/my-trips-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: MyTripsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyTripsPageRoutingModule", function() { return MyTripsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _my_trips_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-trips.page */ "./src/app/my-trips/my-trips.page.ts");
/* harmony import */ var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth/auth.guard */ "./src/app/auth/auth.guard.ts");





const routes = [
    {
        path: "tabs",
        component: _my_trips_page__WEBPACK_IMPORTED_MODULE_3__["MyTripsPage"],
        children: [
            {
                path: "favorite-trips",
                children: [
                    {
                        path: "",
                        loadChildren: () => Promise.all(/*! import() | favorite-trips-favorite-trips-module */[__webpack_require__.e("common"), __webpack_require__.e("favorite-trips-favorite-trips-module")]).then(__webpack_require__.bind(null, /*! ../favorite-trips/favorite-trips.module */ "./src/app/favorite-trips/favorite-trips.module.ts")).then((m) => m.FavoriteTripsPageModule),
                        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]],
                    },
                ],
            },
            {
                path: "booked-trips",
                children: [
                    {
                        path: "",
                        loadChildren: () => __webpack_require__.e(/*! import() | booked-trips-booked-trips-module */ "booked-trips-booked-trips-module").then(__webpack_require__.bind(null, /*! ../booked-trips/booked-trips.module */ "./src/app/booked-trips/booked-trips.module.ts")).then((m) => m.BookedTripsPageModule),
                        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]],
                    },
                ],
            },
            {
                path: "inquiry-trips",
                children: [
                    {
                        path: "",
                        loadChildren: () => __webpack_require__.e(/*! import() | inquiry-trips-inquiry-trips-module */ "inquiry-trips-inquiry-trips-module").then(__webpack_require__.bind(null, /*! ../inquiry-trips/inquiry-trips.module */ "./src/app/inquiry-trips/inquiry-trips.module.ts")).then((m) => m.InquiryTripsPageModule),
                        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]],
                    },
                ],
            },
            {
                path: "",
                redirectTo: "/trips/my-trips/tabs/favorite-trips",
                pathMatch: "full",
            },
        ],
    },
    {
        path: "",
        redirectTo: "/trips/my-trips/tabs/favorite-trips",
        pathMatch: "full",
    },
];
let MyTripsPageRoutingModule = class MyTripsPageRoutingModule {
};
MyTripsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MyTripsPageRoutingModule);



/***/ }),

/***/ "./src/app/my-trips/my-trips.module.ts":
/*!*********************************************!*\
  !*** ./src/app/my-trips/my-trips.module.ts ***!
  \*********************************************/
/*! exports provided: MyTripsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyTripsPageModule", function() { return MyTripsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _my_trips_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./my-trips-routing.module */ "./src/app/my-trips/my-trips-routing.module.ts");
/* harmony import */ var _my_trips_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./my-trips.page */ "./src/app/my-trips/my-trips.page.ts");







let MyTripsPageModule = class MyTripsPageModule {
};
MyTripsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _my_trips_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyTripsPageRoutingModule"]
        ],
        declarations: [_my_trips_page__WEBPACK_IMPORTED_MODULE_6__["MyTripsPage"]]
    })
], MyTripsPageModule);



/***/ }),

/***/ "./src/app/my-trips/my-trips.page.scss":
/*!*********************************************!*\
  !*** ./src/app/my-trips/my-trips.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL215LXRyaXBzL215LXRyaXBzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/my-trips/my-trips.page.ts":
/*!*******************************************!*\
  !*** ./src/app/my-trips/my-trips.page.ts ***!
  \*******************************************/
/*! exports provided: MyTripsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyTripsPage", function() { return MyTripsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let MyTripsPage = class MyTripsPage {
    constructor() { }
    ngOnInit() {
    }
};
MyTripsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-my-trips',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./my-trips.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/my-trips/my-trips.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./my-trips.page.scss */ "./src/app/my-trips/my-trips.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], MyTripsPage);



/***/ })

}]);
//# sourceMappingURL=my-trips-my-trips-module-es2015.js.map