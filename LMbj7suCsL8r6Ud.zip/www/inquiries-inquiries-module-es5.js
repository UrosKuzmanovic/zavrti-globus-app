(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["inquiries-inquiries-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/inquiries/inquiries.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/inquiries/inquiries.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n    <ion-title>Pregled poslatih upita</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/auth/admin.guard.ts":
  /*!*************************************!*\
    !*** ./src/app/auth/admin.guard.ts ***!
    \*************************************/

  /*! exports provided: AdminGuard */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AdminGuard", function () {
      return AdminGuard;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    let AdminGuard = class AdminGuard {
      constructor(authService, router) {
        this.authService = authService;
        this.router = router;
      }

      canLoad(route, segments) {
        return this.authService.userIsAdmin.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(isAdmin => {
          if (!isAdmin) {
            this.router.navigateByUrl("/home");
          }
        }));
      }

    };

    AdminGuard.ctorParameters = () => [{
      type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }];

    AdminGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])], AdminGuard);
    /***/
  },

  /***/
  "./src/app/inquiries/inquiries-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/inquiries/inquiries-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: InquiriesPageRoutingModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InquiriesPageRoutingModule", function () {
      return InquiriesPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _inquiries_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./inquiries.page */
    "./src/app/inquiries/inquiries.page.ts");
    /* harmony import */


    var _auth_admin_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../auth/admin.guard */
    "./src/app/auth/admin.guard.ts");
    /* harmony import */


    var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../auth/auth.guard */
    "./src/app/auth/auth.guard.ts");

    const routes = [{
      path: '',
      component: _inquiries_page__WEBPACK_IMPORTED_MODULE_3__["InquiriesPage"]
    }, {
      path: 'inquiry',
      loadChildren: () => __webpack_require__.e(
      /*! import() | inquiry-inquiry-module */
      "inquiry-inquiry-module").then(__webpack_require__.bind(null,
      /*! ../inquiry/inquiry.module */
      "./src/app/inquiry/inquiry.module.ts")).then(m => m.InquiryPageModule),
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_5__["AuthGuard"], _auth_admin_guard__WEBPACK_IMPORTED_MODULE_4__["AdminGuard"]]
    }, {
      path: 'new-inquiry',
      loadChildren: () => Promise.all(
      /*! import() | new-inquiry-new-inquiry-module */
      [__webpack_require__.e("common"), __webpack_require__.e("new-inquiry-new-inquiry-module")]).then(__webpack_require__.bind(null,
      /*! ../new-inquiry/new-inquiry.module */
      "./src/app/new-inquiry/new-inquiry.module.ts")).then(m => m.NewInquiryPageModule),
      canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_5__["AuthGuard"]]
    }];
    let InquiriesPageRoutingModule = class InquiriesPageRoutingModule {};
    InquiriesPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], InquiriesPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/inquiries/inquiries.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/inquiries/inquiries.module.ts ***!
    \***********************************************/

  /*! exports provided: InquiriesPageModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InquiriesPageModule", function () {
      return InquiriesPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _inquiries_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./inquiries-routing.module */
    "./src/app/inquiries/inquiries-routing.module.ts");
    /* harmony import */


    var _inquiries_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./inquiries.page */
    "./src/app/inquiries/inquiries.page.ts");

    let InquiriesPageModule = class InquiriesPageModule {};
    InquiriesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _inquiries_routing_module__WEBPACK_IMPORTED_MODULE_5__["InquiriesPageRoutingModule"]],
      declarations: [_inquiries_page__WEBPACK_IMPORTED_MODULE_6__["InquiriesPage"]]
    })], InquiriesPageModule);
    /***/
  },

  /***/
  "./src/app/inquiries/inquiries.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/inquiries/inquiries.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2lucXVpcmllcy9pbnF1aXJpZXMucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/inquiries/inquiries.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/inquiries/inquiries.page.ts ***!
    \*********************************************/

  /*! exports provided: InquiriesPage */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InquiriesPage", function () {
      return InquiriesPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    let InquiriesPage = class InquiriesPage {
      constructor() {}

      ngOnInit() {}

    };
    InquiriesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-inquiries',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./inquiries.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/inquiries/inquiries.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./inquiries.page.scss */
      "./src/app/inquiries/inquiries.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], InquiriesPage);
    /***/
  }
}]);
//# sourceMappingURL=inquiries-inquiries-module-es5.js.map