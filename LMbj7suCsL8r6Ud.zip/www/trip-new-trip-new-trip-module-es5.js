(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["trip-new-trip-new-trip-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/trip/new-trip/new-trip.page.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/trip/new-trip/new-trip.page.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n    <ion-title>{{ trip.tripID ? trip.city : 'Unesi novo putovanje'}}</ion-title>\r\n    <!-- <ion-icon name=\"checkmark-outline\" slot=\"end\" style=\"font-size: 4vh;\" class=\"ion-padding\"></ion-icon> -->\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div>\r\n    <form #form=\"ngForm\">\r\n      <div class=\"auth-style\">\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Grad</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.city\" name=\"city\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Država</ion-label>\r\n          <ion-select [(ngModel)]=\"trip.country.countryID\" interface=\"action-sheet\" name=\"country\" ngModel required>\r\n            <ion-select-option *ngFor=\"let country of countries\" [value]=\"country.countryID\">{{ country.name }}\r\n            </ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n        <ion-grid class=\"ion-no-padding\">\r\n          <ion-row class=\"ion-no-padding\">\r\n            <ion-col size=\"6\">\r\n              <ion-item class=\"auth-input-item-style\">\r\n                <ion-label position=\"floating\">Datum putovanja</ion-label>\r\n                <ion-datetime display-format=\"DD MMM YYYY\" [(ngModel)]=\"dateFrom\" name=\"travelDate\" ngModel required>\r\n                </ion-datetime>\r\n              </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n              <ion-item class=\"auth-input-item-style\">\r\n                <ion-label position=\"floating\">Datum povratka</ion-label>\r\n                <ion-datetime display-format=\"DD MMM YYYY\" [(ngModel)]=\"dateTo\" name=\"returnDate\" ngModel required>\r\n                </ion-datetime>\r\n              </ion-item>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Cena</ion-label>\r\n          <ion-input type=\"number\" [(ngModel)]=\"trip.price\" name=\"price\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Hotel</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.hotel\" name=\"hotel\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Aerodrom</ion-label>\r\n          <ion-select [(ngModel)]=\"trip.airport.airportID\" interface=\"action-sheet\" name=\"airport\" ngModel required>\r\n            <ion-select-option *ngFor=\"let airport of airports\" [value]=\"airport.airportID\">{{ airport.airportName }}\r\n            </ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Prtljag</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.baggage\" name=\"baggage\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Obrok</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.meal\" name=\"meal\" ngModel></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Citat</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.quote\" name=\"quote\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Autor</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.author\" name=\"author\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Opis</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.description\" name=\"description\" ngModel></ion-input>\r\n        </ion-item>\r\n        <ion-item class=\"auth-input-item-style\">\r\n          <ion-label position=\"floating\">Link slike</ion-label>\r\n          <ion-input type=\"text\" [(ngModel)]=\"trip.imageSrc\" name=\"imageSrc\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <div class=\"auth-button-style\">\r\n          <ion-button type=\"submit\" (click)=\"onSubmit(form)\" class=\"auth-input-item-style\" [disabled]=\"!form.valid\">\r\n            {{ trip.tripID ? 'Izmeni putovanje' : 'Unesi putovanje' }}\r\n          </ion-button>\r\n          <ion-button type=\"button\" class=\"auth-input-item-style\" fill=\"clear\" (click)=\"clearFields()\">\r\n            Očisti sva polja\r\n          </ion-button>\r\n        </div>\r\n      </div>\r\n    </form>\r\n  </div>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/trip/new-trip/new-trip-routing.module.ts":
  /*!**********************************************************!*\
    !*** ./src/app/trip/new-trip/new-trip-routing.module.ts ***!
    \**********************************************************/

  /*! exports provided: NewTripPageRoutingModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewTripPageRoutingModule", function () {
      return NewTripPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _new_trip_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./new-trip.page */
    "./src/app/trip/new-trip/new-trip.page.ts");

    const routes = [{
      path: '',
      component: _new_trip_page__WEBPACK_IMPORTED_MODULE_3__["NewTripPage"]
    }];
    let NewTripPageRoutingModule = class NewTripPageRoutingModule {};
    NewTripPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NewTripPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/trip/new-trip/new-trip.module.ts":
  /*!**************************************************!*\
    !*** ./src/app/trip/new-trip/new-trip.module.ts ***!
    \**************************************************/

  /*! exports provided: NewTripPageModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewTripPageModule", function () {
      return NewTripPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _new_trip_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./new-trip-routing.module */
    "./src/app/trip/new-trip/new-trip-routing.module.ts");
    /* harmony import */


    var _new_trip_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./new-trip.page */
    "./src/app/trip/new-trip/new-trip.page.ts");

    let NewTripPageModule = class NewTripPageModule {};
    NewTripPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _new_trip_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewTripPageRoutingModule"]],
      declarations: [_new_trip_page__WEBPACK_IMPORTED_MODULE_6__["NewTripPage"]]
    })], NewTripPageModule);
    /***/
  },

  /***/
  "./src/app/trip/new-trip/new-trip.page.scss":
  /*!**************************************************!*\
    !*** ./src/app/trip/new-trip/new-trip.page.scss ***!
    \**************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".auth-style {\n  width: 90vw;\n  display: block;\n  margin: 0vh auto;\n}\n\n.auth-input-style {\n  margin: 0vh auto;\n}\n\n.auth-input-item-style {\n  padding-top: 1vh;\n}\n\n.auth-button-style {\n  margin-top: 3vh;\n}\n\nion-img {\n  width: 40vw;\n  display: block;\n  margin: auto;\n}\n\nion-button {\n  display: block;\n  margin: auto;\n  width: 80%;\n  height: 7vh;\n  padding-top: 1vh;\n}\n\n.item-interactive.item-has-focus {\n  --highlight-background: none;\n}\n\n.item-interactive.item-has-focus ion-label {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdHJpcC9uZXctdHJpcC9DOlxcVXNlcnNcXE9va2VlXFxEZXNrdG9wXFxaYXZydGkgZ2xvYnVzXFx6YXZydGlnbG9idXMtaW9uaWMvc3JjXFxhcHBcXHRyaXBcXG5ldy10cmlwXFxuZXctdHJpcC5wYWdlLnNjc3MiLCJzcmMvYXBwL3RyaXAvbmV3LXRyaXAvbmV3LXRyaXAucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0FDQ0o7O0FERUU7RUFDRSxXQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsNEJBQUE7QUNDSjs7QURFRTtFQUNFLFlBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3RyaXAvbmV3LXRyaXAvbmV3LXRyaXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF1dGgtc3R5bGUge1xyXG4gICAgd2lkdGg6IDkwdnc7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbjogMHZoIGF1dG87XHJcbiAgfVxyXG4gIFxyXG4gIC5hdXRoLWlucHV0LXN0eWxlIHtcclxuICAgIG1hcmdpbjogMHZoIGF1dG87XHJcbiAgfVxyXG4gIFxyXG4gIC5hdXRoLWlucHV0LWl0ZW0tc3R5bGUge1xyXG4gICAgcGFkZGluZy10b3A6IDF2aDtcclxuICB9XHJcbiAgXHJcbiAgLmF1dGgtYnV0dG9uLXN0eWxlIHtcclxuICAgIG1hcmdpbi10b3A6IDN2aDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWltZyB7XHJcbiAgICB3aWR0aDogNDB2dztcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gIH1cclxuICBcclxuICBpb24tYnV0dG9uIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgd2lkdGg6IDgwJTtcclxuICAgIGhlaWdodDogN3ZoO1xyXG4gICAgcGFkZGluZy10b3A6IDF2aDtcclxuICB9XHJcbiAgXHJcbiAgLml0ZW0taW50ZXJhY3RpdmUuaXRlbS1oYXMtZm9jdXMge1xyXG4gICAgLS1oaWdobGlnaHQtYmFja2dyb3VuZDogbm9uZTtcclxuICB9XHJcbiAgXHJcbiAgLml0ZW0taW50ZXJhY3RpdmUuaXRlbS1oYXMtZm9jdXMgaW9uLWxhYmVsIHtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICB9XHJcbiAgIiwiLmF1dGgtc3R5bGUge1xuICB3aWR0aDogOTB2dztcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogMHZoIGF1dG87XG59XG5cbi5hdXRoLWlucHV0LXN0eWxlIHtcbiAgbWFyZ2luOiAwdmggYXV0bztcbn1cblxuLmF1dGgtaW5wdXQtaXRlbS1zdHlsZSB7XG4gIHBhZGRpbmctdG9wOiAxdmg7XG59XG5cbi5hdXRoLWJ1dHRvbi1zdHlsZSB7XG4gIG1hcmdpbi10b3A6IDN2aDtcbn1cblxuaW9uLWltZyB7XG4gIHdpZHRoOiA0MHZ3O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiBhdXRvO1xufVxuXG5pb24tYnV0dG9uIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgd2lkdGg6IDgwJTtcbiAgaGVpZ2h0OiA3dmg7XG4gIHBhZGRpbmctdG9wOiAxdmg7XG59XG5cbi5pdGVtLWludGVyYWN0aXZlLml0ZW0taGFzLWZvY3VzIHtcbiAgLS1oaWdobGlnaHQtYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLml0ZW0taW50ZXJhY3RpdmUuaXRlbS1oYXMtZm9jdXMgaW9uLWxhYmVsIHtcbiAgY29sb3I6IGJsYWNrO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/trip/new-trip/new-trip.page.ts":
  /*!************************************************!*\
    !*** ./src/app/trip/new-trip/new-trip.page.ts ***!
    \************************************************/

  /*! exports provided: NewTripPage */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewTripPage", function () {
      return NewTripPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_models_trip_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/models/trip.model */
    "./src/app/models/trip.model.ts");
    /* harmony import */


    var _new_trip_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./new-trip.service */
    "./src/app/trip/new-trip/new-trip.service.ts");
    /* harmony import */


    var src_app_models_country_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/models/country.model */
    "./src/app/models/country.model.ts");
    /* harmony import */


    var src_app_models_airport_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/models/airport.model */
    "./src/app/models/airport.model.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var src_app_models_user_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/models/user.model */
    "./src/app/models/user.model.ts");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! src/app/auth/auth.service */
    "./src/app/auth/auth.service.ts");

    let NewTripPage = class NewTripPage {
      constructor(route, newTripService, authService) {
        this.route = route;
        this.newTripService = newTripService;
        this.authService = authService;
        this.trip = new src_app_models_trip_model__WEBPACK_IMPORTED_MODULE_3__["Trip"](null, null, new src_app_models_country_model__WEBPACK_IMPORTED_MODULE_5__["Country"](null, null, null, null), null, null, null, null, new src_app_models_airport_model__WEBPACK_IMPORTED_MODULE_6__["Airport"](null, null), null, null, null, null, null, null, null, null, null, new src_app_models_user_model__WEBPACK_IMPORTED_MODULE_8__["User"](null, null, null, null, null, null, null));
      }

      ngOnInit() {
        this.route.paramMap.subscribe(paramMap => {
          if (paramMap.has("tripID")) {
            this.tripID = +paramMap.get("tripID");
            this.tripSub = this.newTripService.fetchTripByID(this.tripID).subscribe(trip => {
              this.trip = trip;
              console.log(this.trip);
              console.log(this.trip.postDate.toISOString());
              this.dateFrom = this.dateFormat(this.trip.travelDate);
              this.dateTo = this.dateFormat(this.trip.returnDate);
            });
          }
        });
        this.newTripService.fetchCountries().subscribe(countries => {
          this.countries = countries;
        });
        this.newTripService.fetchAirports().subscribe(airports => {
          this.airports = airports;
        });
      }

      ionViewWillLeave() {
        this.trip = new src_app_models_trip_model__WEBPACK_IMPORTED_MODULE_3__["Trip"](null, null, new src_app_models_country_model__WEBPACK_IMPORTED_MODULE_5__["Country"](null, null, null, null), null, null, null, null, new src_app_models_airport_model__WEBPACK_IMPORTED_MODULE_6__["Airport"](null, null), null, null, null, null, null, null, null, null, null, new src_app_models_user_model__WEBPACK_IMPORTED_MODULE_8__["User"](null, null, null, null, null, null, null));
      }

      onSubmit(f) {
        this.authService.userID.subscribe(userID => {
          console.log(userID);
          const newTrip = new src_app_models_trip_model__WEBPACK_IMPORTED_MODULE_3__["Trip"](this.trip ? this.trip.tripID : null, f.value.city, new src_app_models_country_model__WEBPACK_IMPORTED_MODULE_5__["Country"](f.value.country, null, null, null), f.value.price, f.value.travelDate, f.value.returnDate, this.trip.tripID ? this.trip.postDate : new Date(), new src_app_models_airport_model__WEBPACK_IMPORTED_MODULE_6__["Airport"](f.value.airport, null), f.value.baggage, f.value.hotel, null, null, f.value.meal, f.value.quote, f.value.author, f.value.description, f.value.imageSrc, new src_app_models_user_model__WEBPACK_IMPORTED_MODULE_8__["User"](userID, null, null, null, null, null, null));
          console.log(newTrip);

          if (this.trip.tripID) {
            this.newTripService.updateTrip(newTrip).subscribe(() => {
              console.log("Apdejtovao");
            });
          } else {
            this.newTripService.insertTrip(newTrip).subscribe(() => {
              console.log("Ubacio novo");
            });
          }
        });
      }

      clearFields() {
        this.form.reset();
      }

      dateFormat(date) {
        return new Date(date.setHours(date.getHours() - date.getTimezoneOffset() / 60)).toISOString().split("T")[0];
      }

    };

    NewTripPage.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _new_trip_service__WEBPACK_IMPORTED_MODULE_4__["NewTripService"]
    }, {
      type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_9__["AuthService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("form", {
      static: false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgForm"])], NewTripPage.prototype, "form", void 0);
    NewTripPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: "app-new-trip",
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./new-trip.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/trip/new-trip/new-trip.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./new-trip.page.scss */
      "./src/app/trip/new-trip/new-trip.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _new_trip_service__WEBPACK_IMPORTED_MODULE_4__["NewTripService"], src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_9__["AuthService"]])], NewTripPage);
    /***/
  },

  /***/
  "./src/app/trip/new-trip/new-trip.service.ts":
  /*!***************************************************!*\
    !*** ./src/app/trip/new-trip/new-trip.service.ts ***!
    \***************************************************/

  /*! exports provided: NewTripService */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewTripService", function () {
      return NewTripService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_app_models_trip_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/models/trip.model */
    "./src/app/models/trip.model.ts");
    /* harmony import */


    var src_app_models_country_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/models/country.model */
    "./src/app/models/country.model.ts");
    /* harmony import */


    var src_app_models_airport_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/models/airport.model */
    "./src/app/models/airport.model.ts");
    /* harmony import */


    var src_app_models_user_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/models/user.model */
    "./src/app/models/user.model.ts");
    /* harmony import */


    var src_app_models_continent_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/models/continent.model */
    "./src/app/models/continent.model.ts");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    let NewTripService = class NewTripService {
      constructor(http) {
        this.http = http;
      }

      fetchTripByID(id) {
        return this.http.get("http://".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].ip_adress, ":").concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].port, "/api/trips/trip/").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(fetchedTrip => {
          return new src_app_models_trip_model__WEBPACK_IMPORTED_MODULE_4__["Trip"](fetchedTrip.tripID, fetchedTrip.city, new src_app_models_country_model__WEBPACK_IMPORTED_MODULE_5__["Country"](fetchedTrip.countryID, fetchedTrip.countryName, null, // treba staviti kontinent
          null // treba staviti zastavu
          ), fetchedTrip.price, new Date(fetchedTrip.travelDate), new Date(fetchedTrip.returnDate), new Date(fetchedTrip.postDate), new src_app_models_airport_model__WEBPACK_IMPORTED_MODULE_6__["Airport"](fetchedTrip.airportID, fetchedTrip.airportName), fetchedTrip.baggage, fetchedTrip.hotel, fetchedTrip.hotelLatitude, fetchedTrip.hotelLongitude, fetchedTrip.meal, fetchedTrip.quote, fetchedTrip.author, fetchedTrip.description, fetchedTrip.imageSrc, new src_app_models_user_model__WEBPACK_IMPORTED_MODULE_7__["User"](fetchedTrip.userID, null, null, fetchedTrip.firstName, fetchedTrip.lastName, null, fetchedTrip.role));
        }));
      }

      fetchCountries() {
        return this.http.get("http://".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].ip_adress, ":").concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].port, "/api/countries")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(fetchedCountries => {
          const countries = [];
          fetchedCountries.forEach(fetchedCountry => {
            countries.push(new src_app_models_country_model__WEBPACK_IMPORTED_MODULE_5__["Country"](fetchedCountry.countryID, fetchedCountry.countryName, new src_app_models_continent_model__WEBPACK_IMPORTED_MODULE_8__["Continent"](fetchedCountry.continentID, fetchedCountry.continentName), fetchedCountry.flagSrc));
          });
          return countries;
        }));
      }

      fetchAirports() {
        return this.http.get("http://".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].ip_adress, ":").concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].port, "/api/airports")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(fetchedAirports => {
          const airports = [];
          fetchedAirports.forEach(fetchedAirport => {
            airports.push(fetchedAirport);
          });
          return airports;
        }));
      }

      insertTrip(trip) {
        return this.http.post("http://".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].ip_adress, ":").concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].port, "/api/trips/new-trip"), {
          city: trip.city,
          countryID: trip.country.countryID,
          price: trip.price,
          travelDate: trip.travelDate,
          returnDate: trip.returnDate,
          postDate: trip.postDate,
          airport: trip.airport.airportID,
          baggage: trip.baggage,
          hotel: trip.hotel,
          meal: trip.meal,
          quote: trip.quote,
          author: trip.author,
          description: trip.description,
          imageSrc: trip.imageSrc,
          userID: trip.user.userID
        }, {
          headers: {
            "Content-Type": "application/json"
          }
        });
      }

      updateTrip(trip) {
        return this.http.post("http://".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].ip_adress, ":").concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].port, "/api/trips/update-trip"), {
          tripID: trip.tripID,
          city: trip.city,
          countryID: trip.country.countryID,
          price: trip.price,
          travelDate: trip.travelDate,
          returnDate: trip.returnDate,
          postDate: trip.postDate,
          airport: trip.airport.airportID,
          baggage: trip.baggage,
          hotel: trip.hotel,
          meal: trip.meal,
          quote: trip.quote,
          author: trip.author,
          description: trip.description,
          imageSrc: trip.imageSrc,
          userID: trip.user.userID
        }, {
          headers: {
            "Content-Type": "application/json"
          }
        });
      }

    };

    NewTripService.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
    }];

    NewTripService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: "root"
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], NewTripService);
    /***/
  }
}]);
//# sourceMappingURL=trip-new-trip-new-trip-module-es5.js.map