(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["booked-trips-booked-trips-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/booked-trips/booked-trips.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/booked-trips/booked-trips.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n    <ion-title>Rezervisana putovanja</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-card routerLink=\"/trips/trip\">\r\n    <ion-item>\r\n      <ion-thumbnail>\r\n        <img src=\"../../assets/img/trips/1.jpg\" />\r\n      </ion-thumbnail>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"8\">\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-title class=\"ion-no-padding\">Mongolija</ion-title>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-text class=\"ion-no-padding\">20-31. maj 2020.</ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-col>\r\n          <ion-col size=\"4\" class=\"col-price\">\r\n            <ion-title class=\"ion-no-padding text-price\"><strong>650e</strong></ion-title>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n      <ion-icon name=\"chevron-forward-outline\" slot=\"end\" class=\"ion-no-margin\"></ion-icon>\r\n    </ion-item>\r\n  </ion-card>\r\n  \r\n  <ion-card routerLink=\"/trips/trip\">\r\n    <ion-item>\r\n      <ion-thumbnail>\r\n        <img src=\"../../assets/img/trips/1.jpg\" />\r\n      </ion-thumbnail>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"8\">\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-title class=\"ion-no-padding\">Mongolija</ion-title>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-text class=\"ion-no-padding\">20-31. maj 2020.</ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-col>\r\n          <ion-col size=\"4\" class=\"col-price\">\r\n            <ion-title class=\"ion-no-padding text-price\"><strong>650e</strong></ion-title>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n      <ion-icon name=\"chevron-forward-outline\" slot=\"end\" class=\"ion-no-margin\"></ion-icon>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card routerLink=\"/trips/trip\">\r\n    <ion-item>\r\n      <ion-thumbnail>\r\n        <img src=\"../../assets/img/trips/1.jpg\" />\r\n      </ion-thumbnail>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"8\">\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-title class=\"ion-no-padding\">Mongolija</ion-title>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-text class=\"ion-no-padding\">20-31. maj 2020.</ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-col>\r\n          <ion-col size=\"4\" class=\"col-price\">\r\n            <ion-title class=\"ion-no-padding text-price\"><strong>650e</strong></ion-title>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n      <ion-icon name=\"chevron-forward-outline\" slot=\"end\" class=\"ion-no-margin\"></ion-icon>\r\n    </ion-item>\r\n  </ion-card>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/booked-trips/booked-trips-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/booked-trips/booked-trips-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: BookedTripsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookedTripsPageRoutingModule", function() { return BookedTripsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _booked_trips_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./booked-trips.page */ "./src/app/booked-trips/booked-trips.page.ts");




const routes = [
    {
        path: '',
        component: _booked_trips_page__WEBPACK_IMPORTED_MODULE_3__["BookedTripsPage"]
    }
];
let BookedTripsPageRoutingModule = class BookedTripsPageRoutingModule {
};
BookedTripsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], BookedTripsPageRoutingModule);



/***/ }),

/***/ "./src/app/booked-trips/booked-trips.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/booked-trips/booked-trips.module.ts ***!
  \*****************************************************/
/*! exports provided: BookedTripsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookedTripsPageModule", function() { return BookedTripsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _booked_trips_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./booked-trips-routing.module */ "./src/app/booked-trips/booked-trips-routing.module.ts");
/* harmony import */ var _booked_trips_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./booked-trips.page */ "./src/app/booked-trips/booked-trips.page.ts");







let BookedTripsPageModule = class BookedTripsPageModule {
};
BookedTripsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _booked_trips_routing_module__WEBPACK_IMPORTED_MODULE_5__["BookedTripsPageRoutingModule"]
        ],
        declarations: [_booked_trips_page__WEBPACK_IMPORTED_MODULE_6__["BookedTripsPage"]]
    })
], BookedTripsPageModule);



/***/ }),

/***/ "./src/app/booked-trips/booked-trips.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/booked-trips/booked-trips.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-price {\n  text-align: right;\n}\n\n.col-price {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYm9va2VkLXRyaXBzL0M6XFxVc2Vyc1xcT29rZWVcXERlc2t0b3BcXFphdnJ0aSBnbG9idXNcXHphdnJ0aWdsb2J1cy1pb25pYy9zcmNcXGFwcFxcYm9va2VkLXRyaXBzXFxib29rZWQtdHJpcHMucGFnZS5zY3NzIiwic3JjL2FwcC9ib29rZWQtdHJpcHMvYm9va2VkLXRyaXBzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvYm9va2VkLXRyaXBzL2Jvb2tlZC10cmlwcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dC1wcmljZSB7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxufVxyXG5cclxuLmNvbC1wcmljZSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59IiwiLnRleHQtcHJpY2Uge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLmNvbC1wcmljZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/booked-trips/booked-trips.page.ts":
/*!***************************************************!*\
  !*** ./src/app/booked-trips/booked-trips.page.ts ***!
  \***************************************************/
/*! exports provided: BookedTripsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookedTripsPage", function() { return BookedTripsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let BookedTripsPage = class BookedTripsPage {
    constructor() { }
    ngOnInit() {
    }
};
BookedTripsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-booked-trips',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./booked-trips.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/booked-trips/booked-trips.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./booked-trips.page.scss */ "./src/app/booked-trips/booked-trips.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], BookedTripsPage);



/***/ })

}]);
//# sourceMappingURL=booked-trips-booked-trips-module-es2015.js.map