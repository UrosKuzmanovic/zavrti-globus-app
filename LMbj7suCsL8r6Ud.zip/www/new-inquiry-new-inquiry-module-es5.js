(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["new-inquiry-new-inquiry-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/new-inquiry/new-inquiry.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/new-inquiry/new-inquiry.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n    <ion-title>Pošalji upit</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form #f=\"ngForm\" (ngSubmit)=\"onSubmit(f)\">\r\n    <ion-grid class=\"ion-padding\">\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-item>\r\n            <ion-label position=\"floating\">Grad <ion-text color=\"medium\">(opciono)</ion-text>\r\n            </ion-label>\r\n            <ion-input type=\"text\" name=\"city\" ngModel></ion-input>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-item>\r\n            <ion-label position=\"floating\">Država</ion-label>\r\n            <ion-select name=\"country\" ngModel required interface=\"action-sheet\">\r\n              <ion-select-option *ngFor=\"let country of countries\" [value]=\"country.countryID\">{{ country.name }}\r\n              </ion-select-option>\r\n            </ion-select>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"6\">\r\n          <ion-item>\r\n            <ion-label position=\"floating\">Datum putovanja</ion-label>\r\n            <ion-datetime display-format=\"DD MMM YYYY\" picker-format=\"DD MMM YYYY\" name=\"travelDate\" ngModel required\r\n              [min]=\"minDate\" [max]=\"maxDate\" #travelDateCtrl=\"ngModel\">\r\n            </ion-datetime>\r\n          </ion-item>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n          <ion-item>\r\n            <ion-label position=\"floating\">Datum povratka</ion-label>\r\n            <ion-datetime display-format=\"DD MMM YYYY\" picker-format=\"DD MMM YYYY\" name=\"returnDate\" ngModel required\r\n              [min]=\"travelDateCtrl.value\" [max]=\"maxDate\">\r\n            </ion-datetime>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-item>\r\n            <ion-label position=\"floating\">Maksimalna cena <ion-text color=\"medium\">(u evrima)</ion-text>\r\n            </ion-label>\r\n            <ion-input type=\"number\" name=\"price\" ngModel required #priceCtrl=\"ngModel\" pattern=\"[0-9]+\"></ion-input>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-item>\r\n            <ion-label position=\"floating\">Dodatni opis o putovanju <ion-text color=\"medium\">(opciono)</ion-text>\r\n            </ion-label>\r\n            <ion-textarea rows=\"3\" name=\"description\" ngModel></ion-textarea>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col></ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-button type=\"submit\" expand=\"block\" shape=\"round\" [disabled]=\"!f.valid\">\r\n            Pošalji upit\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/new-inquiry/new-inquiry-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/new-inquiry/new-inquiry-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: NewInquiryPageRoutingModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewInquiryPageRoutingModule", function () {
      return NewInquiryPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _new_inquiry_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./new-inquiry.page */
    "./src/app/new-inquiry/new-inquiry.page.ts");

    const routes = [{
      path: '',
      component: _new_inquiry_page__WEBPACK_IMPORTED_MODULE_3__["NewInquiryPage"]
    }];
    let NewInquiryPageRoutingModule = class NewInquiryPageRoutingModule {};
    NewInquiryPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NewInquiryPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/new-inquiry/new-inquiry.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/new-inquiry/new-inquiry.module.ts ***!
    \***************************************************/

  /*! exports provided: NewInquiryPageModule */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewInquiryPageModule", function () {
      return NewInquiryPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _new_inquiry_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./new-inquiry-routing.module */
    "./src/app/new-inquiry/new-inquiry-routing.module.ts");
    /* harmony import */


    var _new_inquiry_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./new-inquiry.page */
    "./src/app/new-inquiry/new-inquiry.page.ts");

    let NewInquiryPageModule = class NewInquiryPageModule {};
    NewInquiryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _new_inquiry_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewInquiryPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"]],
      declarations: [_new_inquiry_page__WEBPACK_IMPORTED_MODULE_6__["NewInquiryPage"]]
    })], NewInquiryPageModule);
    /***/
  },

  /***/
  "./src/app/new-inquiry/new-inquiry.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/new-inquiry/new-inquiry.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".item-interactive.item-has-focus {\n  --highlight-background: none;\n}\n\n.item-interactive.item-has-focus ion-label {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbmV3LWlucXVpcnkvQzpcXFVzZXJzXFxPb2tlZVxcRGVza3RvcFxcWmF2cnRpIGdsb2J1c1xcemF2cnRpZ2xvYnVzLWlvbmljL3NyY1xcYXBwXFxuZXctaW5xdWlyeVxcbmV3LWlucXVpcnkucGFnZS5zY3NzIiwic3JjL2FwcC9uZXctaW5xdWlyeS9uZXctaW5xdWlyeS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBTUE7RUFDRSw0QkFBQTtBQ0xGOztBRFFBO0VBQ0UsWUFBQTtBQ0xGIiwiZmlsZSI6InNyYy9hcHAvbmV3LWlucXVpcnkvbmV3LWlucXVpcnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gLmVycm9yLW1zZyB7XHJcbi8vICAgZm9udC1zaXplOiAydmg7XHJcbi8vICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xyXG4vLyAgIG1hcmdpbjogMDtcclxuLy8gfVxyXG5cclxuLml0ZW0taW50ZXJhY3RpdmUuaXRlbS1oYXMtZm9jdXMge1xyXG4gIC0taGlnaGxpZ2h0LWJhY2tncm91bmQ6IG5vbmU7XHJcbn1cclxuXHJcbi5pdGVtLWludGVyYWN0aXZlLml0ZW0taGFzLWZvY3VzIGlvbi1sYWJlbCB7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG59XHJcbiIsIi5pdGVtLWludGVyYWN0aXZlLml0ZW0taGFzLWZvY3VzIHtcbiAgLS1oaWdobGlnaHQtYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLml0ZW0taW50ZXJhY3RpdmUuaXRlbS1oYXMtZm9jdXMgaW9uLWxhYmVsIHtcbiAgY29sb3I6IGJsYWNrO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/new-inquiry/new-inquiry.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/new-inquiry/new-inquiry.page.ts ***!
    \*************************************************/

  /*! exports provided: NewInquiryPage */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewInquiryPage", function () {
      return NewInquiryPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _new_inquiry_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./new-inquiry.service */
    "./src/app/new-inquiry/new-inquiry.service.ts");
    /* harmony import */


    var _models_trip_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../models/trip.model */
    "./src/app/models/trip.model.ts");
    /* harmony import */


    var _models_country_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../models/country.model */
    "./src/app/models/country.model.ts");
    /* harmony import */


    var _models_airport_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../models/airport.model */
    "./src/app/models/airport.model.ts");
    /* harmony import */


    var _models_user_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../models/user.model */
    "./src/app/models/user.model.ts");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    let NewInquiryPage = class NewInquiryPage {
      constructor(newInquiryService, authService) {
        this.newInquiryService = newInquiryService;
        this.authService = authService;
        this.minDate = new Date().toISOString();
        this.maxDate = new Date().getFullYear() + 3;
      }

      ngOnInit() {}

      ionViewWillEnter() {
        this.newInquiryService.fetchCountries().subscribe(countries => {
          this.countries = countries;
        });
      }

      onSubmit(f) {
        console.log(f);
        this.authService.userID.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["take"])(1)).subscribe(userID => {
          if (!userID) {
            return;
          } else {
            this.newInquiryService.onSubmit(new _models_trip_model__WEBPACK_IMPORTED_MODULE_3__["Trip"](null, f.value.city.trim(), new _models_country_model__WEBPACK_IMPORTED_MODULE_4__["Country"](f.value.country, null, null, null), f.value.price, f.value.travelDate, f.value.returnDate, new Date(), new _models_airport_model__WEBPACK_IMPORTED_MODULE_5__["Airport"](null, null), null, null, null, null, null, null, null, f.value.description.trim(), null, new _models_user_model__WEBPACK_IMPORTED_MODULE_6__["User"](userID, null, null, null, null, null, null) // treba korisnik
            ));
          }
        });
      }

    };

    NewInquiryPage.ctorParameters = () => [{
      type: _new_inquiry_service__WEBPACK_IMPORTED_MODULE_2__["NewInquiryService"]
    }, {
      type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]
    }];

    NewInquiryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: "app-new-inquiry",
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./new-inquiry.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/new-inquiry/new-inquiry.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./new-inquiry.page.scss */
      "./src/app/new-inquiry/new-inquiry.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_new_inquiry_service__WEBPACK_IMPORTED_MODULE_2__["NewInquiryService"], _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]])], NewInquiryPage);
    /***/
  },

  /***/
  "./src/app/new-inquiry/new-inquiry.service.ts":
  /*!****************************************************!*\
    !*** ./src/app/new-inquiry/new-inquiry.service.ts ***!
    \****************************************************/

  /*! exports provided: NewInquiryService */

  /***/
  function (module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewInquiryService", function () {
      return NewInquiryService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _models_country_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../models/country.model */
    "./src/app/models/country.model.ts");
    /* harmony import */


    var _models_continent_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../models/continent.model */
    "./src/app/models/continent.model.ts");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    let NewInquiryService = class NewInquiryService {
      constructor(http) {
        this.http = http;
      }

      onSubmit(trip) {
        console.log(trip);
        return this.http.post("http://".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].ip_adress, ":").concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].port, "/api/trips/new-inquiry"), {
          city: trip.city,
          countryID: trip.country.countryID,
          travelDate: trip.travelDate,
          returnDate: trip.returnDate,
          postDate: trip.postDate,
          price: trip.price,
          description: trip.description,
          userID: trip.user.userID
        }, {
          headers: {
            "Content-Type": "application/json"
          }
        }).subscribe();
      }

      fetchCountries() {
        return this.http.get("http://".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].ip_adress, ":").concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].port, "/api/countries")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(fetchedCountries => {
          const countries = [];
          fetchedCountries.forEach(fetchedCountry => {
            countries.push(new _models_country_model__WEBPACK_IMPORTED_MODULE_4__["Country"](fetchedCountry.countryID, fetchedCountry.countryName, new _models_continent_model__WEBPACK_IMPORTED_MODULE_5__["Continent"](fetchedCountry.continentID, fetchedCountry.continentName), fetchedCountry.flagSrc));
          });
          return countries;
        }));
      }

    };

    NewInquiryService.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
    }];

    NewInquiryService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: "root"
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], NewInquiryService);
    /***/
  }
}]);
//# sourceMappingURL=new-inquiry-new-inquiry-module-es5.js.map