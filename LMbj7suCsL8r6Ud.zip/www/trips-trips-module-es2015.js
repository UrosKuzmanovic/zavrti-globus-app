(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["trips-trips-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/trips/trips.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/trips/trips.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-menu-button slot=\"start\"></ion-menu-button>\r\n    <ion-title>Sva putovanja</ion-title>\r\n    <ion-icon name=\"filter-outline\" slot=\"end\" class=\"ion-padding\" style=\"font-size: 4vh;\" (click)=\"toggleFilter()\">\r\n    </ion-icon>\r\n    <ion-icon name=\"search-outline\" slot=\"end\" class=\"ion-padding\" style=\"font-size: 4vh;\" (click)=\"toggleSearchBar()\">\r\n    </ion-icon>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-searchbar placeholder=\"Pretraži grad\" (ionChange)=\"onSearchChange($event)\" *ngIf=\"showSearchBar\"></ion-searchbar>\r\n\r\n  <ion-item *ngIf=\"showFilter\">\r\n    <ion-label>Filtriraj po državi</ion-label>\r\n    <!-- treba da ucita drzave iz baze -->\r\n    <ion-select interface=\"popover\" [(ngModel)]=\"selectedCountry\">\r\n      <ion-select-option value=\"all\">Sve države</ion-select-option>\r\n      <ion-select-option value=\"spa\">Španija</ion-select-option>\r\n      <ion-select-option value=\"ger\">Nemačka</ion-select-option>\r\n      <ion-select-option value=\"ita\">Italija</ion-select-option>\r\n      <ion-select-option value=\"chi\">Kina</ion-select-option>\r\n      <ion-select-option value=\"egy\">Egipat</ion-select-option>\r\n      <ion-select-option value=\"gre\">Grčka</ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <!-- <ion-card routerLink=\"/trips/trip\">\r\n    <ion-item>\r\n      <ion-thumbnail>\r\n        <img src=\"../../assets/img/trips/1.jpg\" />\r\n      </ion-thumbnail>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col>\r\n            <ion-title class=\"ion-padding-start\">Mongolija</ion-title>\r\n          </ion-col>\r\n          <ion-col offset=\"1\">\r\n            <ion-title class=\"ion-no-padding text-price\">300e</ion-title>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <ion-text class=\"ion-padding-start\">20-31. maj 2020.</ion-text>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n      <ion-icon name=\"chevron-forward-outline\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card routerLink=\"/trips/trip\">\r\n    <ion-item>\r\n      <ion-thumbnail>\r\n        <img src=\"../../assets/img/trips/2.jpg\" />\r\n      </ion-thumbnail>\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col>\r\n            <ion-title class=\"ion-padding-start\">Faro</ion-title>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <ion-text class=\"ion-padding-start\">4-11. jun 2020.</ion-text>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n      <ion-icon name=\"chevron-forward-outline\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card routerLink=\"/trips/trip\">\r\n    <ion-item>\r\n      <ion-thumbnail>\r\n        <img src=\"../../assets/img/trips/3.jpg\" />\r\n      </ion-thumbnail>\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col>\r\n            <ion-title class=\"ion-padding-start\">Prag</ion-title>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <ion-text class=\"ion-padding-start\">28-31. mart 2020.</ion-text>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n      <ion-icon name=\"chevron-forward-outline\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n  </ion-card> -->\r\n\r\n  <div *ngFor=\"let trip of trips\">\r\n    <ion-card [routerLink]=\"['/', 'trips', 'trip', trip.tripID]\">\r\n      <ion-item>\r\n        <ion-thumbnail>\r\n          <img [src]='trip.imageSrc ? trip.imageSrc : defaultImg' />\r\n        </ion-thumbnail>\r\n        <ion-grid>\r\n          <ion-row>\r\n            <ion-col size=\"8\">\r\n              <ion-row>\r\n                <ion-col>\r\n                  <ion-title class=\"ion-no-padding\"><strong>{{ trip.city ? trip.city : trip.country.name }}</strong>\r\n                  </ion-title>\r\n                </ion-col>\r\n              </ion-row>\r\n              <ion-row>\r\n                <ion-col>\r\n                  <ion-text class=\"ion-no-padding\">{{ dateFormat(trip.travelDate, trip.returnDate) }}</ion-text>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-col>\r\n            <ion-col size=\"4\" class=\"col-price\">\r\n              <ion-title class=\"ion-no-padding text-price\"><strong>{{ trip.price }} &euro;</strong></ion-title>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n        <ion-icon name=\"chevron-forward-outline\" slot=\"end\" class=\"ion-no-margin\"></ion-icon>\r\n      </ion-item>\r\n    </ion-card>\r\n  </div>\r\n\r\n</ion-content>");

/***/ }),

/***/ "./src/app/trips/trips-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/trips/trips-routing.module.ts ***!
  \***********************************************/
/*! exports provided: TripsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripsPageRoutingModule", function() { return TripsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _trips_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./trips.page */ "./src/app/trips/trips.page.ts");




const routes = [
    {
        path: '',
        component: _trips_page__WEBPACK_IMPORTED_MODULE_3__["TripsPage"]
    },
    {
        path: 'trip',
        loadChildren: () => Promise.all(/*! import() | trip-trip-module */[__webpack_require__.e("common"), __webpack_require__.e("trip-trip-module")]).then(__webpack_require__.bind(null, /*! ../trip/trip.module */ "./src/app/trip/trip.module.ts")).then(m => m.TripPageModule)
    },
    {
        path: 'my-trips',
        loadChildren: () => __webpack_require__.e(/*! import() | my-trips-my-trips-module */ "my-trips-my-trips-module").then(__webpack_require__.bind(null, /*! ../my-trips/my-trips.module */ "./src/app/my-trips/my-trips.module.ts")).then(m => m.MyTripsPageModule)
    }
];
let TripsPageRoutingModule = class TripsPageRoutingModule {
};
TripsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TripsPageRoutingModule);



/***/ }),

/***/ "./src/app/trips/trips.module.ts":
/*!***************************************!*\
  !*** ./src/app/trips/trips.module.ts ***!
  \***************************************/
/*! exports provided: TripsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripsPageModule", function() { return TripsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _trips_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./trips-routing.module */ "./src/app/trips/trips-routing.module.ts");
/* harmony import */ var _trips_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./trips.page */ "./src/app/trips/trips.page.ts");







let TripsPageModule = class TripsPageModule {
};
TripsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _trips_routing_module__WEBPACK_IMPORTED_MODULE_5__["TripsPageRoutingModule"]
        ],
        declarations: [_trips_page__WEBPACK_IMPORTED_MODULE_6__["TripsPage"]]
    })
], TripsPageModule);



/***/ }),

/***/ "./src/app/trips/trips.page.scss":
/*!***************************************!*\
  !*** ./src/app/trips/trips.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-price {\n  text-align: right;\n}\n\n.col-price {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdHJpcHMvQzpcXFVzZXJzXFxPb2tlZVxcRGVza3RvcFxcWmF2cnRpIGdsb2J1c1xcemF2cnRpZ2xvYnVzLWlvbmljL3NyY1xcYXBwXFx0cmlwc1xcdHJpcHMucGFnZS5zY3NzIiwic3JjL2FwcC90cmlwcy90cmlwcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQ0NKOztBREVBO0VBQ0ksb0JBQUE7RUFBQSxhQUFBO0VBQ0Esd0JBQUE7VUFBQSx1QkFBQTtFQUNBLHlCQUFBO1VBQUEsbUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3RyaXBzL3RyaXBzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50ZXh0LXByaWNlIHtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcblxyXG4uY29sLXByaWNlIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn0iLCIudGV4dC1wcmljZSB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4uY29sLXByaWNlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59Il19 */");

/***/ }),

/***/ "./src/app/trips/trips.page.ts":
/*!*************************************!*\
  !*** ./src/app/trips/trips.page.ts ***!
  \*************************************/
/*! exports provided: TripsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripsPage", function() { return TripsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _trips_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./trips.service */ "./src/app/trips/trips.service.ts");



let TripsPage = class TripsPage {
    constructor(tripsService) {
        this.tripsService = tripsService;
        this.showSearchBar = false;
        this.showFilter = false;
        this.selectedCountry = "all";
        this.defaultImg = "../../assets/img/trips/1.jpg";
    }
    ngOnInit() {
        this.tripsSub = this.tripsService.trips.subscribe((trips) => {
            this.trips = trips;
            this.tripsCopy = trips;
        }, (error) => {
            console.log("Doslo je do greske");
            console.log(error);
        });
    }
    ngOnDestroy() {
        if (this.tripsSub) {
            this.tripsSub.unsubscribe();
        }
    }
    ionViewWillEnter() {
        this.tripsService.fetchTrips().subscribe();
    }
    ionViewDidLeave() {
        this.showSearchBar = false;
        this.showFilter = false;
    }
    toggleSearchBar() {
        this.showSearchBar = !this.showSearchBar;
        this.showFilter = false;
    }
    toggleFilter() {
        this.showFilter = !this.showFilter;
        this.showSearchBar = false;
    }
    dateFormat(dateFrom, dateTo) {
        var dayFrom = dateFrom.getUTCDate();
        var monthFrom = dateFrom.getUTCMonth() + 1;
        var yearFrom = dateFrom.getUTCFullYear();
        var dayTo = dateTo.getUTCDate();
        var monthTo = dateTo.getUTCMonth() + 1;
        var yearTo = dateTo.getUTCFullYear();
        if (yearFrom === yearTo) {
            if (monthFrom === monthTo) {
                if (dayFrom === dayTo) {
                    return `${dayFrom}. ${this.monthFormat(monthFrom)} ${yearFrom}.`;
                }
                else {
                    return `${dayFrom}-${dayTo}. ${this.monthFormat(monthFrom)} ${yearFrom}.`;
                }
            }
            else {
                return `${dayFrom}. ${this.monthFormat(monthFrom)} - ${dayTo}. ${this.monthFormat(monthTo)} ${yearFrom}.`;
            }
        }
        else {
            return `${dayFrom}. ${this.monthFormat(monthFrom)} ${yearFrom} - ${dayTo}. ${this.monthFormat(monthTo)} ${yearTo}.`;
        }
    }
    monthFormat(month) {
        switch (month) {
            case 1:
                return "jan";
            case 2:
                return "feb";
            case 3:
                return "mar";
            case 4:
                return "apr";
            case 5:
                return "maj";
            case 6:
                return "jun";
            case 7:
                return "jul";
            case 8:
                return "avg";
            case 9:
                return "sep";
            case 10:
                return "okt";
            case 11:
                return "nov";
            case 12:
                return "dec";
            default:
                return "null";
        }
    }
    onSearchChange($event) {
        this.trips = this.tripsCopy;
        const search = $event.detail.value;
        this.trips = this.trips.filter((trip) => trip.city.toLowerCase().indexOf(search.toLowerCase()) !== -1);
    }
};
TripsPage.ctorParameters = () => [
    { type: _trips_service__WEBPACK_IMPORTED_MODULE_2__["TripsService"] }
];
TripsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-trips",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./trips.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/trips/trips.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./trips.page.scss */ "./src/app/trips/trips.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_trips_service__WEBPACK_IMPORTED_MODULE_2__["TripsService"]])
], TripsPage);



/***/ }),

/***/ "./src/app/trips/trips.service.ts":
/*!****************************************!*\
  !*** ./src/app/trips/trips.service.ts ***!
  \****************************************/
/*! exports provided: TripsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripsService", function() { return TripsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _models_trip_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../models/trip.model */ "./src/app/models/trip.model.ts");
/* harmony import */ var _models_country_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../models/country.model */ "./src/app/models/country.model.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");








let TripsService = class TripsService {
    constructor(http) {
        this.http = http;
        this._trips = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([
        // {
        //   tripID: 1,
        //   city: 'Moskva',
        //   country: 'Rusija',
        //   travelDate: new Date('2020-05-02'),
        //   returnDate: new Date('2020-05-09'),
        //   price: 350,
        //   imageSrc: '../../assets/img/trips/1.jpg'
        // },
        // {
        //   tripID: 2,
        //   city: 'Antalija',
        //   country: 'Turska',
        //   travelDate: new Date('2020-06-19'),
        //   returnDate: new Date('2020-06-29'),
        //   price: 500,
        //   imageSrc: '../../assets/img/trips/2.jpg'
        // },
        // {
        //   tripID: 3,
        //   city: 'Sevilja',
        //   country: 'Španija',
        //   travelDate: new Date('2020-05-10'),
        //   returnDate: new Date('2020-05-14'),
        //   price: 240,
        //   imageSrc: '../../assets/img/trips/3.jpg'
        // }
        ]);
    }
    get trips() {
        return this._trips.asObservable();
    }
    getTrip(id) {
        return this._trips.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((trips) => {
            return Object.assign({}, trips.find((trip) => trip.tripID === id));
        }));
    }
    addTrip(trip) {
        this._trips.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1)).subscribe((trips) => {
            this._trips.next(trips.concat(trip));
        });
    }
    fetchTrips() {
        return this.http
            .get(`http://${src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].ip_adress}:${src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].port}/api/trips/listedtrips`)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((fetchedTrip) => {
            const trips = [];
            for (const key in fetchedTrip) {
                if (fetchedTrip.hasOwnProperty(key)) {
                    trips.push(new _models_trip_model__WEBPACK_IMPORTED_MODULE_5__["Trip"](fetchedTrip[key].tripID, fetchedTrip[key].city, new _models_country_model__WEBPACK_IMPORTED_MODULE_6__["Country"](fetchedTrip[key].countryID, fetchedTrip[key].countryName, null, // treba staviti kontinent
                    null // treba staviti zastavu
                    ), fetchedTrip[key].price, new Date(fetchedTrip[key].travelDate), new Date(fetchedTrip[key].returnDate), null, // treba staviti postDate
                    null, null, null, null, null, null, null, null, null, fetchedTrip[key].imageSrc, null));
                }
            }
            return trips;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])((trips) => {
            this._trips.next(trips);
        }));
    }
};
TripsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TripsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], TripsService);



/***/ })

}]);
//# sourceMappingURL=trips-trips-module-es2015.js.map